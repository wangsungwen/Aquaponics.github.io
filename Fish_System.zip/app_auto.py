import paho.mqtt.client as mqtt
import sqlite3
import json
import time
import datetime
import requests
import schedule
import threading
import webbrowser  # [新增] 匯入瀏覽器控制模組
from flask import Flask, send_from_directory

# ================= 配置區域 =================
# MQTT 設定 (後端 Python 使用 TCP 1883)
MQTT_BROKER = "MQTTGO.io"
MQTT_PORT = 1883

# 主題設定
TOPIC_SENSORS = "ttu_fish/sensors"
TOPIC_PUMP    = "ttu_fish/relay/pump"
TOPIC_HEATER  = "ttu_fish/relay/heater"
TOPIC_FEEDER  = "ttu_fish/relay/feeder"

# Telegram 設定
TELEGRAM_TOKEN = "您的_BOT_TOKEN"
TELEGRAM_CHAT_ID = "您的_CHAT_ID"

# 閾值設定
LIMIT_LEVEL_LOW = 1000
LIMIT_TDS_HIGH = 800
LIMIT_TEMP_LOW = 20.0

# ================= Flask Web Server 設定 =================
app = Flask(__name__, static_folder='.')

@app.route('/')
def index():
    # 當瀏覽器訪問 127.0.0.1:5000 時，回傳 index.html
    return send_from_directory('.', 'index.html')

def run_web_server():
    # 啟動 Web 伺服器 (Port 5000)
    # use_reloader=False 是為了避免在 Thread 中執行時重複啟動
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)

# ================= 資料庫與邏輯 =================
def init_db():
    conn = sqlite3.connect('fish_system.db', check_same_thread=False)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS sensors
                 (timestamp DATETIME, temp REAL, level INTEGER, 
                  tds REAL, turbidity REAL, ph REAL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS logs
                 (timestamp DATETIME, event_type TEXT, message TEXT)''')
    conn.commit()
    conn.close()

def log_event(event_type, message):
    try:
        conn = sqlite3.connect('fish_system.db', check_same_thread=False)
        c = conn.cursor()
        c.execute("INSERT INTO logs VALUES (?, ?, ?)", 
                  (datetime.datetime.now(), event_type, message))
        conn.commit()
        conn.close()
        print(f"[{event_type}] {message}")
    except Exception as e:
        print(f"DB Error: {e}")

def send_telegram(msg):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": msg}
    try:
        requests.post(url, json=payload, timeout=2)
    except:
        pass

def control_relay(topic, state):
    client.publish(topic, state, retain=True)

# ================= 排程任務 =================
def job_feed():
    log_event("FEEDER", "自動餵食啟動")
    control_relay(TOPIC_FEEDER, "ON")
    time.sleep(3)
    control_relay(TOPIC_FEEDER, "OFF")

# ================= MQTT 邏輯 =================
def on_connect(client, userdata, flags, rc):
    print(f"MQTT Connected (rc={rc})")
    client.subscribe(TOPIC_SENSORS)

def on_message(client, userdata, msg):
    try:
        payload = json.loads(msg.payload.decode())
        temp = float(payload.get("temp", 0))
        level = int(payload.get("level", 0))
        tds = float(payload.get("tds", 0))
        
        # 寫入 DB
        conn = sqlite3.connect('fish_system.db', check_same_thread=False)
        c = conn.cursor()
        c.execute("INSERT INTO sensors VALUES (?, ?, ?, ?, ?, ?)", 
                  (datetime.datetime.now(), temp, level, tds, 
                   payload.get("turbidity",0), payload.get("ph_raw",0)))
        conn.commit()
        conn.close()

        # 自動化判斷
        if level < LIMIT_LEVEL_LOW:
            pass 
            
        if tds > LIMIT_TDS_HIGH:
            control_relay(TOPIC_PUMP, "ON")
        else:
            control_relay(TOPIC_PUMP, "OFF")

        if temp < LIMIT_TEMP_LOW:
            control_relay(TOPIC_HEATER, "ON")
        else:
            control_relay(TOPIC_HEATER, "OFF")

    except Exception as e:
        print(f"Data Error: {e}")

# ================= 主程式入口 =================
if __name__ == "__main__":
    print("系統啟動中...")
    init_db()

    # 1. 啟動 Web Server (使用獨立執行緒)
    web_thread = threading.Thread(target=run_web_server)
    web_thread.daemon = True # 主程式結束時，Web Server 也會關閉
    web_thread.start()
    print("Web Server 已啟動 -> http://127.0.0.1:5000")

    # [新增] 自動開啟瀏覽器
    def open_browser():
        time.sleep(1.5) # 等待 1.5 秒確保 Server 已經 ready
        webbrowser.open("http://127.0.0.1:5000")
    
    # 使用另一個 Thread 來開瀏覽器，避免卡住後面的流程
    threading.Thread(target=open_browser).start()

    # 2. 設定 MQTT
    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message
    
    try:
        client.connect(MQTT_BROKER, MQTT_PORT, 60)
        client.loop_start() # MQTT 背景執行
    except Exception as e:
        print(f"MQTT 連線失敗: {e}")

    # 3. 設定排程
    schedule.every().day.at("08:00").do(job_feed)
    schedule.every().day.at("20:00").do(job_feed)

    print("系統運作中 (按 Ctrl+C 可關閉)...")

    # 4. 主迴圈 (維持程式運作)
    try:
        while True:
            schedule.run_pending()
            time.sleep(1)
    except KeyboardInterrupt:
        print("系統關閉")
        client.loop_stop()
        client.disconnect()