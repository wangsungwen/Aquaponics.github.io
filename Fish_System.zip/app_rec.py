import paho.mqtt.client as mqtt
import sqlite3
import json
import time
import datetime
import requests
import schedule
import threading
import webbrowser
import os
import cv2
from flask import Flask, send_from_directory, jsonify, Response

# ================= 配置區域 =================
MQTT_BROKER = "MQTTGO.io"
MQTT_PORT = 1883
TOPIC_SENSORS = "ttu_fish/sensors"
TOPIC_PUMP    = "ttu_fish/relay/pump"
TOPIC_HEATER  = "ttu_fish/relay/heater"
TOPIC_FEEDER  = "ttu_fish/relay/feeder"

# 影像串流來源
RTSP_URL = "rtsp://10.197.186.146:554/11"
VIDEO_DIR = "static/videos"

# 閾值設定
LIMIT_LEVEL_LOW = 1000      # 水位過低閾值
LIMIT_TDS_HIGH = 800        # TDS 過高閾值
LIMIT_TURBIDITY_LOW = 2.5   # 混濁度電壓 (越低越髒)
LIMIT_PH_HIGH = 8.5         # PH 過高
LIMIT_TEMP_LOW = 20.0       # 水溫過低

# [重要] Telegram 設定 (請填入您的資訊)
TELEGRAM_TOKEN = "您的_BOT_TOKEN"
TELEGRAM_CHAT_ID = "您的_CHAT_ID"

# ================= 初始化 =================
if not os.path.exists(VIDEO_DIR):
    os.makedirs(VIDEO_DIR)

app = Flask(__name__, static_folder='static')

# ================= 影像錄製功能 =================
def record_event_clip(event_name, duration=10):
    def task():
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{timestamp}_{event_name}.mp4"
        filepath = os.path.join(VIDEO_DIR, filename)
        
        print(f"🎥 開始錄影: {filename}")
        cap = cv2.VideoCapture(RTSP_URL)
        fourcc = cv2.VideoWriter_fourcc(*'mp4v') 
        fps = 20.0
        
        ret, frame = cap.read()
        if not ret:
            print("❌ 無法連接 RTSP，錄影取消")
            return
        
        height, width, _ = frame.shape
        out = cv2.VideoWriter(filepath, fourcc, fps, (width, height))
        
        start_time = time.time()
        while (time.time() - start_time) < duration:
            ret, frame = cap.read()
            if ret:
                out.write(frame)
            else:
                break
        
        cap.release()
        out.release()
        print(f"✅ 錄影完成: {filename}")
        log_event("VIDEO", f"已錄製事件影片: {filename}")

    threading.Thread(target=task).start()

# ================= Web API =================
@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/api/logs')
def get_logs():
    conn = sqlite3.connect('fish_system.db', check_same_thread=False)
    c = conn.cursor()
    c.execute("SELECT timestamp, event_type, message FROM logs ORDER BY timestamp DESC LIMIT 20")
    data = c.fetchall()
    conn.close()
    return jsonify(data)

@app.route('/api/videos')
def get_videos():
    files = sorted(os.listdir(VIDEO_DIR), reverse=True)
    video_files = [f for f in files if f.endswith(".mp4")]
    return jsonify(video_files)

@app.route('/static/videos/<path:filename>')
def serve_video(filename):
    return send_from_directory(VIDEO_DIR, filename)

# ================= 影像串流功能 =================
def gen_frames():
    cap = cv2.VideoCapture(RTSP_URL)
    while True:
        success, frame = cap.read()
        if not success:
            break
        else:
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    cap.release()

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

# ================= 資料庫與通知邏輯 =================
def init_db():
    conn = sqlite3.connect('fish_system.db', check_same_thread=False)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS sensors
                 (timestamp DATETIME, temp REAL, level INTEGER, 
                  tds REAL, turbidity REAL, ph REAL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS logs
                 (timestamp DATETIME, event_type TEXT, message TEXT)''')
    conn.commit()
    conn.close()

def log_event(event_type, message):
    try:
        conn = sqlite3.connect('fish_system.db', check_same_thread=False)
        c = conn.cursor()
        c.execute("INSERT INTO logs VALUES (?, ?, ?)", 
                  (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), event_type, message))
        conn.commit()
        conn.close()
        print(f"[{event_type}] {message}")
    except Exception as e:
        print(f"DB Error: {e}")

# [核心] 發送 Telegram 推播
def send_telegram(msg):
    if "您的" in TELEGRAM_TOKEN: # 檢查使用者是否忘記設定
        print("❌ Telegram Token 未設定，跳過發送")
        return

    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": msg}
    try:
        requests.post(url, json=payload, timeout=5)
        print(f"📱 Telegram 推播已發送: {msg}")
    except Exception as e:
        print(f"❌ Telegram 發送失敗: {e}")

# [核心] 控制繼電器 (整合了 錄影 + Log + 推播)
def control_relay(topic, state, trigger_msg=""):
    client.publish(topic, state, retain=True)
    
    # 只有當狀態是 ON 且有觸發訊息時 (代表是自動觸發)，才執行通知流程
    if state == "ON" and trigger_msg:
        # 1. 寫入 Log
        log_event("AUTO_CONTROL", trigger_msg)
        
        # 2. [新增推播] 發送 Telegram
        send_telegram(f"🚨 自動警報觸發\n----------------\n{trigger_msg}\n(系統已自動啟動對應設備)")
        
        # 3. 觸發錄影
        record_event_clip("auto_event", duration=10)

# ================= MQTT 邏輯 =================
def on_message(client, userdata, msg):
    try:
        payload = json.loads(msg.payload.decode())
        temp = float(payload.get("temp", 0))
        level = int(payload.get("level", 0))
        tds = float(payload.get("tds", 0))
        turb = float(payload.get("turbidity", 5.0))
        ph = float(payload.get("ph", 7.0))
        
        # 存入 DB
        conn = sqlite3.connect('fish_system.db', check_same_thread=False)
        c = conn.cursor()
        c.execute("INSERT INTO sensors VALUES (?, ?, ?, ?, ?, ?)", 
                  (datetime.datetime.now(), temp, level, tds, turb, ph))
        conn.commit()
        conn.close()

        # --- 自動化判斷 ---
        
        # 1. 水位過低告警 (單獨判斷，因為這通常不直接開馬達，而是純告警)
        if level < LIMIT_LEVEL_LOW:
            warn_msg = f"⚠️ 危險：水位過低！目前數值: {level}"
            # 簡單防抖機制 (避免每秒都發)，這裡簡化處理：
            # 實務上建議加一個變數 last_alert_time 來判斷間隔
            print(warn_msg)
            # 若希望水位低也一直發推播，請取消下面這行的註解：
            # send_telegram(warn_msg)

        # 2. 水質異常 (混濁度 OR TDS OR PH) -> 啟動過濾
        if (turb < LIMIT_TURBIDITY_LOW) or (tds > LIMIT_TDS_HIGH) or (ph > LIMIT_PH_HIGH):
            reason = []
            if turb < LIMIT_TURBIDITY_LOW: reason.append(f"混濁度異常({turb:.1f}V)")
            if tds > LIMIT_TDS_HIGH: reason.append(f"TDS過高({tds})")
            if ph > LIMIT_PH_HIGH: reason.append(f"PH過高({ph})")
            
            msg_str = " | ".join(reason) + " -> 啟動過濾"
            control_relay(TOPIC_PUMP, "ON", msg_str)
        else:
            client.publish(TOPIC_PUMP, "OFF", retain=True)

        # 3. 溫度控制
        if temp < LIMIT_TEMP_LOW:
            control_relay(TOPIC_HEATER, "ON", f"❄️ 水溫過低({temp}°C) -> 啟動加熱")
        else:
            client.publish(TOPIC_HEATER, "OFF", retain=True)

    except Exception as e:
        print(f"Error processing data: {e}")

# ================= 排程任務 =================
def job_feed():
    msg = "⏰ 定時餵食任務已啟動"
    log_event("FEEDER", msg)
    
    # [新增推播]
    send_telegram(f"🐟 {msg}\n(正在錄影紀錄中...)")
    
    # 觸發錄影
    record_event_clip("feeding", duration=15)
    
    client.publish(TOPIC_FEEDER, "ON", retain=True)
    time.sleep(3)
    client.publish(TOPIC_FEEDER, "OFF", retain=True)

# ================= 主程式 =================
if __name__ == "__main__":
    init_db()
    
    # 啟動 Web Server
    web_thread = threading.Thread(target=lambda: app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False))
    web_thread.daemon = True
    web_thread.start()

    # 自動開瀏覽器
    def open_browser():
        time.sleep(2)
        webbrowser.open("http://127.0.0.1:5000")
    threading.Thread(target=open_browser).start()

    # MQTT
    client = mqtt.Client()
    client.on_connect = lambda c, u, f, rc: c.subscribe(TOPIC_SENSORS)
    client.on_message = on_message
    
    try:
        client.connect(MQTT_BROKER, MQTT_PORT, 60)
        client.loop_start()
    except Exception as e:
        print(f"MQTT 連線失敗: {e}")

    # 排程設定
    schedule.every().day.at("08:00").do(job_feed)
    schedule.every().day.at("20:00").do(job_feed)
    
    # 測試用：每 60 秒模擬一次餵食 (您可以解開註解測試推播功能)
    # schedule.every(60).seconds.do(job_feed)

    print("系統運行中... 按 Ctrl+C 結束")
    try:
        while True:
            schedule.run_pending()
            time.sleep(1)
    except KeyboardInterrupt:
        client.disconnect()