import time
import threading
import json
import sqlite3
import requests  # 新增: 用於抓取 ThingSpeak 數據
from flask import Flask, render_template, Response
from flask_mqtt import Mqtt

app = Flask(__name__)

# ================= 設定區 (請修改這裡) =================
# MQTT 設定 (仍然需要，用於發送控制指令給 ESP8266 馬達)
app.config['MQTT_BROKER_URL'] = 'mqttgo.io'
app.config['MQTT_BROKER_PORT'] = 1883
app.config['MQTT_USERNAME'] = '' 
app.config['MQTT_PASSWORD'] = '' 
app.config['MQTT_REFRESH_TIME'] = 1.0 
mqtt = Mqtt(app)

# ThingSpeak 設定
THINGSPEAK_CHANNEL_ID = '3146597'
THINGSPEAK_READ_API_KEY = 'YOUR_READ_API_KEY' # ⚠️ 請填入您的 Read API Key
POLLING_INTERVAL = 20  # 每 20 秒抓一次 (配合 ESP32 上傳頻率)

# 全域變數 (儲存最新狀態)
current_data = {
    'temp': 0, 'tds': 0, 'ph': 0, 'turbidity': 0, 'water_level': 0
}

# ================= 資料庫與 MQTT 控制 =================
def init_db():
    conn = sqlite3.connect('fish_system.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS sensor_logs 
                 (timestamp DATETIME DEFAULT CURRENT_TIMESTAMP, 
                  temp REAL, tds REAL, ph REAL, turbidity REAL, water_level REAL)''')
    conn.commit()
    conn.close()

def save_to_db(data):
    try:
        conn = sqlite3.connect('fish_system.db')
        c = conn.cursor()
        c.execute("INSERT INTO sensor_logs (temp, tds, ph, turbidity, water_level) VALUES (?, ?, ?, ?, ?)",
                  (data['temp'], data['tds'], data['ph'], data['turbidity'], data['water_level']))
        conn.commit()
        conn.close()
        print("✅ 數據已存入資料庫")
    except Exception as e:
        print(f"資料庫錯誤: {e}")

# ================= 核心：ThingSpeak 抓取執行緒 =================
def fetch_thingspeak_loop():
    """
    這是一個背景執行緒，不斷去 ThingSpeak 抓取最新資料
    """
    print("🚀 ThingSpeak 監聽執行緒已啟動...")
    while True:
        try:
            # 1. 呼叫 ThingSpeak API (取得最後 1 筆資料)
            url = f"https://api.thingspeak.com/channels/{THINGSPEAK_CHANNEL_ID}/feeds.json?api_key={THINGSPEAK_READ_API_KEY}&results=1"
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                feeds = data.get('feeds', [])
                
                if len(feeds) > 0:
                    last_feed = feeds[0]
                    
                    # 2. 更新全域變數 (對應您的 ESP32 上傳順序)
                    # Field 1:Temp, 2:TDS, 3:PH, 4:Turb, 5:Level
                    # 注意：ThingSpeak 回傳的是字串，需轉為 float
                    global current_data
                    current_data['temp'] = float(last_feed.get('field1', 0) or 0)
                    current_data['tds'] = float(last_feed.get('field2', 0) or 0)
                    current_data['ph'] = float(last_feed.get('field3', 0) or 0)
                    current_data['turbidity'] = float(last_feed.get('field4', 0) or 0)
                    current_data['water_level'] = float(last_feed.get('field5', 0) or 0)
                    
                    print(f"📥 從雲端同步數據: {current_data}")
                    
                    # 3. 執行自動化邏輯檢查
                    check_logic(current_data)
                    
                    # 4. 存入本地資料庫 (備份用)
                    save_to_db(current_data)
                    
            else:
                print(f"⚠️ ThingSpeak 連線失敗 Code: {response.status_code}")
                
        except Exception as e:
            print(f"❌ 抓取錯誤: {e}")
            
        # 休息 20 秒再抓下一次
        time.sleep(POLLING_INTERVAL)

# ================= 自動化邏輯 (Logic) =================
def check_logic(data):
    """
    根據抓回來的數據判斷是否開啟設備
    """
    # 範例：水溫過低 -> 開加熱棒
    if data['temp'] < 20 and data['temp'] > 0:
        print("❄️ 水溫過低！發送 MQTT 開啟加熱棒...")
        mqtt.publish('fish/control/heater', 'ON')
        # 這裡可以加入 Telegram 通知程式碼
    
    # 範例：水太髒 (濁度電壓低代表髒，需依實際校正調整)
    # 假設 2.5V 以下為髒
    if data['turbidity'] < 2.5 and data['turbidity'] > 0:
        print("💩 水質混濁！發送 MQTT 開啟過濾馬達...")
        mqtt.publish('fish/control/pump', 'ON')

# ================= Flask 路由 =================
@app.route('/')
def index():
    # 將最新數據傳遞給網頁
    return render_template('index.html', data=current_data)

@app.route('/api/data')
def get_data():
    # 提供 API 給網頁 AJAX 抓取 (如果網頁不想用 iframe)
    return json.dumps(current_data)

# ================= 主程式啟動 =================
if __name__ == '__main__':
    init_db()
    
    # 啟動 ThingSpeak 抓取執行緒
    t = threading.Thread(target=fetch_thingspeak_loop)
    t.daemon = True # 設定為守護執行緒，主程式關閉時它也會關閉
    t.start()
    
    # 啟動 Web Server
    app.run(host='0.0.0.0', port=5000, debug=False)