import time
import threading
import json
import sqlite3
import requests  # 用於抓取 ThingSpeak 數據 & 發送 Telegram
import cv2
from flask import Flask, render_template, Response, request, jsonify
from flask_mqtt import Mqtt
from datetime import datetime, timedelta

app = Flask(__name__)

# ================= 設定區 (請修改這裡) =================
# 1. MQTT 設定 (控制硬體用)
app.config['MQTT_BROKER_URL'] = 'mqttgo.io'
app.config['MQTT_BROKER_PORT'] = 1883
app.config['MQTT_USERNAME'] = '' 
app.config['MQTT_PASSWORD'] = '' 
app.config['MQTT_REFRESH_TIME'] = 1.0 
mqtt = Mqtt(app)

# 2. ThingSpeak 設定 (讀取數據用)
THINGSPEAK_CHANNEL_ID = '3146597'
THINGSPEAK_READ_API_KEY = 'UHJB60PCIX9UDOZW' # ⚠️ 請填入您的 Read API Key
POLLING_INTERVAL = 20  # 每 20 秒抓一次

# 3. Telegram 推播設定 (新增部分 🆕)
TELEGRAM_BOT_TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN' # ⚠️ 請填入 Bot Token
TELEGRAM_CHAT_ID = 'YOUR_CHAT_ID'              # ⚠️ 請填入您的 Chat ID

# 全域變數 (儲存最新狀態)
current_data = {
    'temp': 0, 'tds': 0, 'ph': 0, 'turbidity': 0, 'water_level': 0
}

# 警報冷卻紀錄 (避免手機狂響) - 單位: 秒
last_alert_time = {
    'heater': 0,
    'pump': 0,
    'water_level': 0
}
ALERT_COOLDOWN = 1800 # 設定 1800 秒 = 30 分鐘內不重複發送同一種警報

# ================= 功能函式 =================

def send_telegram_alert(message):
    """
    發送 Telegram 訊息的通用函式
    """
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        payload = {
            'chat_id': TELEGRAM_CHAT_ID,
            'text': message
        }
        requests.post(url, data=payload)
        print(f"🔔 Telegram 通知已發送: {message}")
    except Exception as e:
        print(f"❌ Telegram 發送失敗: {e}")

def init_db():
    conn = sqlite3.connect('fish_system.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS sensor_logs 
                 (timestamp DATETIME DEFAULT CURRENT_TIMESTAMP, 
                  temp REAL, tds REAL, ph REAL, turbidity REAL, water_level REAL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS system_events 
                 (timestamp DATETIME DEFAULT CURRENT_TIMESTAMP, 
                  event_type TEXT, message TEXT)''')
    conn.commit()
    conn.close()

def save_to_db(data):
    try:
        conn = sqlite3.connect('fish_system.db')
        c = conn.cursor()
        c.execute("INSERT INTO sensor_logs (temp, tds, ph, turbidity, water_level) VALUES (?, ?, ?, ?, ?)",
                  (data['temp'], data['tds'], data['ph'], data['turbidity'], data['water_level']))
        conn.commit()
        conn.close()
        print("✅ 數據已存入資料庫")
    except Exception as e:
        print(f"資料庫錯誤: {e}")

def log_event(event_type, message):
    try:
        conn = sqlite3.connect('fish_system.db')
        c = conn.cursor()
        # 強制使用 UTC+8 (台灣時間)
        current_time_str = (datetime.utcnow() + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
        c.execute("INSERT INTO system_events (timestamp, event_type, message) VALUES (?, ?, ?)",
                  (current_time_str, event_type, message))
        conn.commit()
        conn.close()
        print(f"📝 系統事件已記錄: [{event_type}] {message}")
    except Exception as e:
        print(f"❌ 記錄事件錯誤: {e}")

# ================= 邏輯判斷核心 (已修改 🆕) =================
def check_logic(data):
    """
    根據抓回來的數據判斷是否開啟設備，並發送通知
    """
    global last_alert_time
    current_time = time.time()

    # --- 邏輯 1: 水溫過低 ---
    if data['temp'] < 20 and data['temp'] > 0:
        print("❄️ 水溫過低！發送 MQTT 開啟加熱棒...")
        mqtt.publish('fish/control/heater', 'ON')
        
        # 檢查冷卻時間，避免重複發送
        if current_time - last_alert_time['heater'] > ALERT_COOLDOWN:
            msg = f"🚨 【低溫警報】\n目前水溫：{data['temp']}°C\n狀態：已自動開啟加熱棒 🔥"
            send_telegram_alert(msg)
            log_event('AUTO_CONTROL', f"低溫 ({data['temp']}°C) -> 開啟加熱棒")
            last_alert_time['heater'] = current_time # 更新最後發送時間
    
    # --- 邏輯 2: 水質混濁 ---
    # 假設濁度電壓低於 2.5V 代表髒
    if data['turbidity'] < 2.5 and data['turbidity'] > 0:
        print("💩 水質混濁！發送 MQTT 開啟過濾馬達...")
        mqtt.publish('fish/control/pump', 'ON')

        if current_time - last_alert_time['pump'] > ALERT_COOLDOWN:
            msg = f"⚠️ 【水質異常】\n濁度數值：{data['turbidity']}V\n狀態：已自動開啟過濾馬達 🔄"
            send_telegram_alert(msg)
            log_event('AUTO_CONTROL', f"水質混濁 ({data['turbidity']}V) -> 開啟馬達")
            last_alert_time['pump'] = current_time

    # --- 邏輯 3: 水位過低 (防止馬達空轉) ---
    # 假設水位低於 10cm 是危險
    if data['water_level'] < 10 and data['water_level'] > 0:
        if current_time - last_alert_time['water_level'] > ALERT_COOLDOWN:
            msg = f"⛔ 【水位危險】\n目前水位：{data['water_level']}cm\n請盡快補水以免馬達燒毀！"
            send_telegram_alert(msg)
            last_alert_time['water_level'] = current_time

# ================= ThingSpeak 抓取執行緒 =================
def fetch_thingspeak_loop():
    print("🚀 ThingSpeak 監聽執行緒已啟動...")
    while True:
        try:
            url = f"https://api.thingspeak.com/channels/{THINGSPEAK_CHANNEL_ID}/feeds.json?api_key={THINGSPEAK_READ_API_KEY}&results=1"
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                feeds = data.get('feeds', [])
                
                if len(feeds) > 0:
                    last_feed = feeds[0]
                    global current_data
                    # 資料轉換
                    current_data['temp'] = float(last_feed.get('field1', 0) or 0)
                    current_data['tds'] = float(last_feed.get('field2', 0) or 0)
                    current_data['ph'] = float(last_feed.get('field3', 0) or 0)
                    current_data['turbidity'] = float(last_feed.get('field4', 0) or 0)
                    current_data['water_level'] = float(last_feed.get('field5', 0) or 0)
                    
                    print(f"📥 從雲端同步數據: {current_data}")
                    
                    # 執行邏輯檢查 (包含 Telegram 推播)
                    check_logic(current_data)
                    
                    # 存入資料庫
                    save_to_db(current_data)
            else:
                print(f"⚠️ ThingSpeak 連線失敗 Code: {response.status_code}")
                
        except Exception as e:
            print(f"❌ 抓取錯誤: {e}")
            
        time.sleep(POLLING_INTERVAL)

# ================= 影像串流功能 (新增 🆕) =================
RTSP_URL = "rtsp://10.197.186.146:554/11"

def gen_frames():
    cap = cv2.VideoCapture(RTSP_URL)
    while True:
        success, frame = cap.read()
        if not success:
            break
        else:
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    cap.release()

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

# ================= Flask 路由 =================
@app.route('/')
def index():
    return render_template('index.html', data=current_data)

@app.route('/api/data')
def get_data():
    return json.dumps(current_data)

@app.route('/api/logs')
def get_logs():
    try:
        conn = sqlite3.connect('fish_system.db')
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT timestamp, event_type, message FROM system_events ORDER BY timestamp DESC LIMIT 20")
        rows = c.fetchall()
        conn.close()
        return jsonify([dict(row) for row in rows])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/log_event', methods=['POST'])
def api_log_event():
    try:
        data = request.json
        log_event(data.get('event_type', 'INFO'), data.get('message', ''))
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ================= 主程式啟動 =================
if __name__ == '__main__':
    init_db()
    
    t = threading.Thread(target=fetch_thingspeak_loop)
    t.daemon = True 
    t.start()
    
    # 測試發送一則開機訊息
    # send_telegram_alert("✅ 魚菜共生系統後端已啟動！")
    
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)