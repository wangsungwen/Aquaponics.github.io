import time
import threading
import json
import sqlite3
import requests  # 用於抓取 ThingSpeak 數據 & 發送 Telegram
import cv2
import webbrowser
import os
from flask import Flask, render_template, Response, request, jsonify
from flask_mqtt import Mqtt
from datetime import datetime, timedelta

app = Flask(__name__)

# 設定區
# 1. MQTT 設定 (控制硬體用)
app.config['MQTT_BROKER_URL'] = 'mqttgo.io'
app.config['MQTT_BROKER_PORT'] = 1883
app.config['MQTT_USERNAME'] = '' 
app.config['MQTT_PASSWORD'] = '' 
app.config['MQTT_REFRESH_TIME'] = 1.0 
mqtt = Mqtt(app)

# 2. ThingSpeak 設定 (讀取數據用)
THINGSPEAK_CHANNEL_ID = '3146597'
THINGSPEAK_READ_API_KEY = 'UHJB60PCIX9UDOZW' # 請填入您的 Read API Key
POLLING_INTERVAL = 20  # 每 20 秒抓一次

# 3. 預設設定 & Config 載入
CONFIG_FILE = 'config.json'
DEFAULT_CONFIG = {
    "rtsp_url": "rtsp://10.197.186.146:554/11",
    "telegram_bot_token": "YOUR_TELEGRAM_BOT_TOKEN",
    "telegram_chat_id": "YOUR_CHAT_ID"
}

def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"讀取 Config 失敗: {e}，使用預設值")
    return DEFAULT_CONFIG.copy()

def save_config(new_config):
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(new_config, f, indent=4, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"寫入 Config 失敗: {e}")
        return False

# 載入設定
app_config = load_config()
TELEGRAM_BOT_TOKEN = app_config.get('telegram_bot_token', DEFAULT_CONFIG['telegram_bot_token'])
TELEGRAM_CHAT_ID = app_config.get('telegram_chat_id', DEFAULT_CONFIG['telegram_chat_id'])

# 計算濁度 NTU (根據電壓)
def calculate_ntu(voltage):
    if voltage < 2.5:
        ntu = 3000
    else:
        ntu = -1120.4 * (voltage ** 2) + 5742.3 * voltage - 4352.9
        if ntu < 0: ntu = 0
        if ntu > 4550: ntu = 4550
    return int(ntu)

# 全域變數 (儲存最新狀態)
current_data = {
    'temp': 0, 'tds': 0, 'ph': 0, 'turbidity': 0, 'turbidity_ntu': 0, 'water_level': 0
}

# 警報冷卻紀錄 (避免手機狂響) - 單位: 秒
last_alert_time = {
    'heater': 0,
    'pump': 0,
    'water_level': 0,
    'tds': 0,
    'ph': 0
}
ALERT_COOLDOWN = 600 # 設定 600 秒 = 10 分鐘內不重複發送同一種警報

# 設備狀態追蹤 (避免重複發送 MQTT OFF)
device_status = {
    'heater': None, # None = Unknown, False = OFF, True = ON
    'pump': None
}

# 功能函式

def send_telegram_alert(message):
    """
    發送 Telegram 訊息的通用函式 (參考 Live Stream Universal v19)
    """
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID: return
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    threading.Thread(target=lambda: requests.post(url, data={'chat_id': TELEGRAM_CHAT_ID, 'text': message}, timeout=2.0)).start()
    print(f"Telegram 通知請求已發送: {message}")

def init_db():
    conn = sqlite3.connect('fish_system.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS sensor_logs 
                 (timestamp DATETIME DEFAULT CURRENT_TIMESTAMP, 
                  temp REAL, tds REAL, ph REAL, turbidity REAL, turbidity_ntu REAL, water_level REAL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS system_events 
                 (timestamp DATETIME DEFAULT CURRENT_TIMESTAMP, 
                  event_type TEXT, message TEXT)''')
    
    # 手動遷移：檢查 sensor_logs 是否有 turbidity_ntu 欄位，沒有則新增
    try:
        c.execute("SELECT turbidity_ntu FROM sensor_logs LIMIT 1")
    except sqlite3.OperationalError:
        print("偵測到舊版資料庫，正在新增 turbidity_ntu 欄位...")
        c.execute("ALTER TABLE sensor_logs ADD COLUMN turbidity_ntu REAL")
        conn.commit()
    
    conn.commit()
    conn.close()

def save_to_db(data):
    try:
        conn = sqlite3.connect('fish_system.db')
        c = conn.cursor()
        c.execute("INSERT INTO sensor_logs (temp, tds, ph, turbidity, turbidity_ntu, water_level) VALUES (?, ?, ?, ?, ?, ?)",
                  (data['temp'], data['tds'], data['ph'], data['turbidity'], data.get('turbidity_ntu', 0), data['water_level']))
        conn.commit()
        conn.close()
        print("數據已存入資料庫")
    except Exception as e:
        print(f"資料庫錯誤: {e}")

def log_event(event_type, message):
    try:
        conn = sqlite3.connect('fish_system.db')
        c = conn.cursor()
        # 強制使用 UTC+8 (台灣時間)
        current_time_str = (datetime.utcnow() + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')
        c.execute("INSERT INTO system_events (timestamp, event_type, message) VALUES (?, ?, ?)",
                  (current_time_str, event_type, message))
        conn.commit()
        conn.close()
        print(f"系統事件已記錄: [{event_type}] {message}")
    except Exception as e:
        print(f"記錄事件錯誤: {e}")

# 邏輯判斷核心
def check_logic(data):
    """
    根據抓回來的數據判斷是否開啟設備，並發送通知
    """
    global last_alert_time
    current_time = time.time()

    # 邏輯 1: 水溫過低
    if data['temp'] < 20 and data['temp'] > 0:
        # 只有當之前是關閉狀態，或需要強制維持開啟時才發送 (這裡簡單處理: 每次偵測到異常都發送 ON 確保開啟)
        
        # 狀態更新
        if device_status['heater'] is not True:
             print("水溫過低！發送 MQTT 開啟加熱棒...")
             mqtt.publish('fish/control/heater', 'ON')
             device_status['heater'] = True
             log_event('AUTO_CONTROL', f"低溫 ({data['temp']}°C) -> 開啟加熱棒")

        # 檢查冷卻時間，發送通知
        if current_time - last_alert_time['heater'] > ALERT_COOLDOWN:
            msg = f"【低溫警報】\n目前水溫：{data['temp']}°C\n狀態：已自動開啟加熱棒"
            send_telegram_alert(msg)
            last_alert_time['heater'] = current_time 
    
    # 邏輯 1-2: 水溫恢復正常 (>= 20C)
    elif data['temp'] >= 20:
        if device_status['heater'] is not False: # 如果之前是開啟的(或是未知的)，現在關閉它
             print("水溫恢復正常！發送 MQTT 關閉加熱棒...")
             mqtt.publish('fish/control/heater', 'OFF')
             device_status['heater'] = False
             log_event('AUTO_CONTROL', f"水溫正常 ({data['temp']}°C) -> 關閉加熱棒")
             send_telegram_alert(f"【水溫恢復】\n目前水溫：{data['temp']}°C\n狀態：已自動關閉加熱棒")

    

    # 邏輯 2 & 4: 水質混濁 OR TDS 過高 (共用過濾馬達)
    ntu = data.get('turbidity_ntu', 0)
    tds = data.get('tds', 0)
    
    # 判斷是否需要過濾 (任一條件成立即開啟)
    pump_needed = False
    reasons = []

    # 條件 A: 濁度過高
    if ntu >= 3000:
        pump_needed = True
        reasons.append(f"濁度過高({ntu} NTU)")
        
        # 濁度警報
        if current_time - last_alert_time['pump'] > ALERT_COOLDOWN:
            msg = f"【水質異常】\n濁度數值：{ntu} NTU ({data['turbidity']}V)\n狀態：已自動開啟過濾馬達"
            send_telegram_alert(msg)
            last_alert_time['pump'] = current_time

    # 條件 B: TDS 過高
    if tds > 200:
        pump_needed = True
        reasons.append(f"TDS過高({tds} ppm)")

        # TDS 警報
        if current_time - last_alert_time.get('tds', 0) > ALERT_COOLDOWN:
            msg = f"【水質異常】\nTDS 數值：{tds} ppm\n狀態：已自動開啟過濾馬達"
            send_telegram_alert(msg)
            # 如果 'tds' key 不在 last_alert_time 初始化字典中，這裡會 traceback 嗎？
            # 最好在上面全域變數區先補上 'tds': 0
            last_alert_time['tds'] = current_time

    # 執行馬達控制
    if pump_needed:
        # 如果需要開啟，且目前是關閉(或未知) -> 開啟
        if device_status['pump'] is not True:
            reason_str = " & ".join(reasons)
            print(f"水質異常 ({reason_str})！發送 MQTT 開啟過濾馬達...")
            mqtt.publish('fish/control/pump', 'ON')
            device_status['pump'] = True
            log_event('AUTO_CONTROL', f"水質異常 ({reason_str}) -> 開啟馬達")
            
    else:
        # 如果不需要開啟 (數值都正常)，且目前是開啟(或未知) -> 關閉
        if device_status['pump'] is not False:
             print("水質(濁度&TDS)皆恢復正常！發送 MQTT 關閉過濾馬達...")
             mqtt.publish('fish/control/pump', 'OFF')
             device_status['pump'] = False
             log_event('AUTO_CONTROL', f"水質恢復 (NTU:{ntu}, TDS:{tds}) -> 關閉馬達")
             send_telegram_alert(f"【水質恢復】\n目前數值：{ntu} NTU / {tds} ppm\n狀態：已自動關閉過濾馬達")

    # 邏輯 3: PH值異常
    ph = data.get('ph', 0)
    if ph > 0:
        ph_msg = ""
        if ph < 6.0:
            ph_msg = f"【PH值異常】\n目前PH值：{ph}\n狀態：水質偏酸性"
        elif ph > 8.0:
            ph_msg = f"【PH值異常】\n目前PH值：{ph}\n狀態：水質偏鹼性"
        
        if ph_msg:
            if current_time - last_alert_time.get('ph', 0) > ALERT_COOLDOWN:
                send_telegram_alert(ph_msg)
                log_event('ALARM', f"PH值異常 ({ph})")
                last_alert_time['ph'] = current_time

    # 邏輯 4: 水位過低 (防止馬達空轉)
    # 假設水位低於 10cm 是危險
    if data['water_level'] < 10 and data['water_level'] > 0:
        if current_time - last_alert_time['water_level'] > ALERT_COOLDOWN:
            msg = f"【水位危險】\n目前水位：{data['water_level']}cm\n請盡快補水以免馬達燒毀！"
            send_telegram_alert(msg)
            log_event('ALARM', f"水位危險 ({data['water_level']}cm) -> 請補水")
            last_alert_time['water_level'] = current_time

# ThingSpeak 抓取執行緒
def fetch_thingspeak_loop():
    print("ThingSpeak 監聽執行緒已啟動...")
    while True:
        try:
            url = f"https://api.thingspeak.com/channels/{THINGSPEAK_CHANNEL_ID}/feeds.json?api_key={THINGSPEAK_READ_API_KEY}&results=1"
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                feeds = data.get('feeds', [])
                
                if len(feeds) > 0:
                    last_feed = feeds[0]
                    global current_data
                    # 資料轉換
                    current_data['temp'] = float(last_feed.get('field1', 0) or 0)
                    current_data['tds'] = float(last_feed.get('field2', 0) or 0)
                    current_data['ph'] = float(last_feed.get('field3', 0) or 0)
                    current_data['turbidity'] = float(last_feed.get('field4', 0) or 0)
                    current_data['turbidity_ntu'] = calculate_ntu(current_data['turbidity'])
                    current_data['water_level'] = float(last_feed.get('field5', 0) or 0)
                    
                    print(f"從雲端同步數據: {current_data}")
                    
                    # 執行邏輯檢查 (包含 Telegram 推播)
                    check_logic(current_data)
                    
                    # 存入資料庫
                    save_to_db(current_data)
            else:
                print(f"ThingSpeak 連線失敗 Code: {response.status_code}")
                
        except Exception as e:
            print(f"抓取錯誤: {e}")
            
        time.sleep(POLLING_INTERVAL)


# 影像串流功能
RTSP_URL = app_config.get('rtsp_url', DEFAULT_CONFIG['rtsp_url'])

class VideoCamera(object):
    def __init__(self):
        self.video = cv2.VideoCapture(RTSP_URL)
        # Set buffer size to strict minimum to avoid lag
        self.video.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        
        self.frame = None
        self.lock = threading.Lock()
        self.running = True
        
        # Start background frame grabber
        self.thread = threading.Thread(target=self.update, args=())
        self.thread.daemon = True
        self.thread.start()

    def __del__(self):
        self.running = False
        if self.video.isOpened():
            self.video.release()

    def update(self):
        """
        Continuously read frames from the stream to keep the buffer empty.
        We only update self.frame when a new frame is successfully read.
        """
        while self.running:
            success, image = self.video.read()
            if success:
                with self.lock:
                    self.frame = image
            else:
                # If connection lost, try to reconnect or wait
                time.sleep(0.1)
            # Sleep slightly to yield CPU
            time.sleep(0.01)

    def get_frame(self):
        with self.lock:
            if self.frame is not None:
                # Encode the frame in JPEG format
                ret, jpeg = cv2.imencode('.jpg', self.frame, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
                if ret:
                    return jpeg.tobytes()
        return None

# Global camera instance (lazy initialization)
camera = None

def generate_frames():
    global camera
    if camera is None:
        camera = VideoCamera()
        
    while True:
        frame_bytes = camera.get_frame()
        if frame_bytes:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
        
        # STRICT 1 FPS LIMIT
        # Sleep for 1 second before sending the next frame
        time.sleep(1.0)

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')


# Flask 路由
@app.route('/')
def index():
    return render_template('index.html', data=current_data)

@app.route('/api/data')
def get_data():
    return json.dumps(current_data)

@app.route('/api/logs')
def get_logs():
    try:
        conn = sqlite3.connect('fish_system.db')
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT timestamp, event_type, message FROM system_events ORDER BY timestamp DESC LIMIT 20")
        rows = c.fetchall()
        conn.close()
        return jsonify([dict(row) for row in rows])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/log_event', methods=['POST'])
def api_log_event():
    try:
        data = request.json
        log_event(data.get('event_type', 'INFO'), data.get('message', ''))
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/settings', methods=['GET', 'POST'])
def handle_settings():
    global app_config, RTSP_URL, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
    
    if request.method == 'GET':
        return jsonify(app_config)
    
    if request.method == 'POST':
        new_settings = request.json
        # Update config object
        app_config.update(new_settings)
        # Save to file
        if save_config(app_config):
            # Update runtime global variables
            RTSP_URL = app_config.get('rtsp_url', RTSP_URL)
            TELEGRAM_BOT_TOKEN = app_config.get('telegram_bot_token', TELEGRAM_BOT_TOKEN)
            TELEGRAM_CHAT_ID = app_config.get('telegram_chat_id', TELEGRAM_CHAT_ID)
            return jsonify({'status': 'success', 'message': '設定已儲存並更新'})
        else:
            return jsonify({'status': 'error', 'message': '寫入設定檔失敗'}), 500

# 主程式啟動
if __name__ == '__main__':
    init_db()
    
    t = threading.Thread(target=fetch_thingspeak_loop)
    t.daemon = True 
    t.start()
    
    # 測試發送一則開機訊息
    # send_telegram_alert("魚菜共生系統後端已啟動！")
    
    # 自動開啟瀏覽器
    def open_browser():
        time.sleep(1.5) # 等待 Server 啟動
        webbrowser.open('http://localhost:5000')

    threading.Thread(target=open_browser).start()

    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)