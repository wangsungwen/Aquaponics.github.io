"""
檔案名稱: main_controller.py
功能: 系統核心，負責邏輯控制、資料庫與排程
"""
import paho.mqtt.client as mqtt
import sqlite3
import json
import time
import datetime
import requests
import schedule 

# --- 設定區 ---
MQTT_BROKER = "MQTTGO.io"
MQTT_PORT = 1883
TOPIC_SENSORS = "ttu_fish/sensors"
# 對應 ESP8266 Relay 的 Topic
TOPIC_PUMP   = "ttu_fish/relay/pump"
TOPIC_HEATER = "ttu_fish/relay/heater"
TOPIC_FEEDER = "ttu_fish/relay/feeder"

TELEGRAM_TOKEN = "請填入您的_BOT_TOKEN"
TELEGRAM_CHAT_ID = "請填入您的_CHAT_ID"

# 告警閾值
LIMIT_LEVEL_LOW = 1000      # [cite: 61]
LIMIT_TDS_HIGH = 800        # [cite: 62]
LIMIT_TEMP_LOW = 20.0       # [cite: 63]

# --- 資料庫函式 [cite: 57] ---
def init_db():
    conn = sqlite3.connect('fish_system.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS sensors
                 (timestamp DATETIME, temp REAL, level INTEGER, 
                  tds REAL, turbidity REAL, ph REAL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS logs
                 (timestamp DATETIME, event_type TEXT, message TEXT)''')
    conn.commit()
    conn.close()

def log_event(event_type, message):
    conn = sqlite3.connect('fish_system.db')
    c = conn.cursor()
    c.execute("INSERT INTO logs VALUES (?, ?, ?)", 
              (datetime.datetime.now(), event_type, message))
    conn.commit()
    conn.close()
    print(f"[{event_type}] {message}")

# --- 通訊函式 ---
def send_telegram(msg):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": msg}
    try:
        requests.post(url, json=payload, timeout=5)
    except:
        pass

def control_relay(topic, state):
    client.publish(topic, state, retain=True)

# --- 餵食排程 [cite: 64] ---
def job_feed():
    log_event("FEEDER", "自動餵食啟動")
    send_telegram("🐟 魚魚吃飯時間到了！")
    control_relay(TOPIC_FEEDER, "ON")
    time.sleep(3) # 餵食器轉動時間
    control_relay(TOPIC_FEEDER, "OFF")

# --- MQTT 處理邏輯 [cite: 59-63] ---
def on_message(client, userdata, msg):
    try:
        payload = json.loads(msg.payload.decode())
        temp = float(payload.get("temp", 0))
        level = int(payload.get("level", 0))
        tds = float(payload.get("tds", 0))
        
        # 存入 DB
        conn = sqlite3.connect('fish_system.db')
        c = conn.cursor()
        c.execute("INSERT INTO sensors VALUES (?, ?, ?, ?, ?, ?)", 
                  (datetime.datetime.now(), temp, level, tds, 
                   payload.get("turbidity",0), payload.get("ph_raw",0)))
        conn.commit()
        conn.close()

        # 邏輯判斷
        if level < LIMIT_LEVEL_LOW:
            send_telegram(f"⚠️ 水位過低警告: {level}")
            
        if tds > LIMIT_TDS_HIGH:
            control_relay(TOPIC_PUMP, "ON")
        else:
            control_relay(TOPIC_PUMP, "OFF")
            
        if temp < LIMIT_TEMP_LOW:
            control_relay(TOPIC_HEATER, "ON")
        else:
            control_relay(TOPIC_HEATER, "OFF")

    except Exception as e:
        print(f"Error: {e}")

# --- 主程式 ---
if __name__ == "__main__":
    init_db()
    client = mqtt.Client()
    client.on_message = on_message
    client.connect(MQTT_BROKER, 1883, 60)
    client.subscribe(TOPIC_SENSORS)
    client.loop_start() # 背景執行 MQTT

    # 設定每12小時餵食 (早上8點與晚上8點)
    schedule.every().day.at("08:00").do(job_feed)
    schedule.every().day.at("20:00").do(job_feed)

    print("系統啟動完成，監控中...")
    
    while True:
        schedule.run_pending()
        time.sleep(1)