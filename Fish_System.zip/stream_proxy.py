import cv2
import threading
import time
import json
import os
from flask import Flask, Response

# Configuration
CONFIG_PATH = 'config.json'

def load_config():
    """Load configuration from config.json if it exists."""
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading config: {e}")
    return {}

config = load_config()
# Default to a placeholder if not found, but try to use usage from config
SOURCE_URL = config.get("rtsp_url", "rtsp://your_camera_ip:554/stream") 

app = Flask(__name__)

class VideoCamera(object):
    def __init__(self):
        self.video = cv2.VideoCapture(SOURCE_URL)
        # Set buffer size to strict minimum to avoid lag
        self.video.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        
        self.frame = None
        self.lock = threading.Lock()
        self.running = True
        
        # Start background frame grabber
        self.thread = threading.Thread(target=self.update, args=())
        self.thread.daemon = True
        self.thread.start()

    def __del__(self):
        self.running = False
        if self.video.isOpened():
            self.video.release()

    def update(self):
        """
        Continuously read frames from the stream to keep the buffer empty.
        We only update self.frame when a new frame is successfully read.
        """
        while self.running:
            success, image = self.video.read()
            if success:
                with self.lock:
                    self.frame = image
            else:
                # If connection lost, try to reconnect or wait
                # print("Failed to read frame, retrying...")
                time.sleep(0.1)
            # Sleep slightly to yield CPU, but not too much or buffer fills
            time.sleep(0.01) 

    def get_frame(self):
        with self.lock:
            if self.frame is not None:
                # Encode the frame in JPEG format
                # Quality 80 is a good balance
                ret, jpeg = cv2.imencode('.jpg', self.frame, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
                if ret:
                    return jpeg.tobytes()
        return None

camera = None

def generate_frames():
    global camera
    if camera is None:
        camera = VideoCamera()
        
    while True:
        frame_bytes = camera.get_frame()
        if frame_bytes:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
        
        # STRICT 1 FPS LIMIT
        # Sleep for 1 second before sending the next frame
        time.sleep(1.0)

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/')
def index():
    return "<html><body><h1>1 FPS Video Stream</h1><img src='/video_feed' /></body></html>"

if __name__ == '__main__':
    print(f"Starting stream from: {SOURCE_URL}")
    print("Serving at http://0.0.0.0:5000/video_feed")
    # Threaded=True is important for multiple viewers, though we limit FPS globally roughly
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
